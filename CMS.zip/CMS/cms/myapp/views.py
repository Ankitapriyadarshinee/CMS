# cms/views.py
from django.shortcuts import render, redirect
from .forms import ContentForm
from .models import Content
# cms/views.py
from django.shortcuts import render, get_object_or_404
from .models import Content

def content_detail(request, content_id):
    content = get_object_or_404(Content, id=content_id)
    return render(request, 'content.html', {'content': content})


def add_content(request):
    if request.method == 'POST':
        form = ContentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('view_content')
    else:
        form = ContentForm()
    return render(request, 'add.html', {'form': form})

def view_content(request):
    contents = Content.objects.all()
    return render(request, 'view.html', {'contents': contents})



