from cms.plugin_base import CMSPluginBase
from cms.plugin_pool import plugin_pool
from django.utils.translation import gettext_lazy as _
from .models import MyCMSPlugin

@plugin_pool.register_plugin
class MyCMSPluginPublisher(CMSPluginBase):
    model = MyCMSPlugin
    name = _("My CMS Plugin")
    render_template = "index.html"
    cache = False  # Disable caching if you need real-time updates

    def render(self, context, instance, placeholder):
        context['instance'] = instance
        return context
