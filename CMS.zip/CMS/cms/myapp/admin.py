from django.contrib import admin

from myapp.models import Content

# Register your models here.
admin.site.register(Content)